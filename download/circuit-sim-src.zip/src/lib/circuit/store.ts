// Zustand store for the circuit editor.
// Holds: components, wires, selection, simulation settings, current sim state.
// Provides: add/move/rotate/delete components, add/remove wires, undo/redo,
// serialize/deserialize, run/pause/step simulation.

'use client';

import { create } from 'zustand';
import type {
  CircuitComponent,
  CircuitDocument,
  ComponentField,
  DrawingPrimitive,
  Group,
  HierarchicalSheet,
  NetClass,
  NoConnectMarker,
  PageSetup,
  PinElecType,
  SavedView,
  SimContext,
  Wire,
} from './types';
import { DEFAULT_PAGE_SETUP, DEFAULT_TITLE_BLOCK } from './types';
import { getPlugin } from './registry';
import { simulateStep, getTerminalsForComponent, buildNodeMap } from './engine';
import { validatePhysics, type PhysicsViolation } from './physics-validator';
import { runFullERC } from './erc';
import { snapshotSheet, flattenHierarchy } from './hierarchy';
import { runAnalysis as runAnalysisEngine, type AnalysisConfig, type AnalysisResult } from './analysis';
import { runBatch as runBatchEngine, type BatchConfig, type BatchResult } from './batch-runner';
import { execMeas, type MeasCommand, type RealTrace as MeasRealTrace, type MeasResult } from './measurement';
import { solveDCRobust as solveDCRobustEngine } from './convergence';
import { DEFAULT_OPTIONS, type SimOptions, type ConvergenceReport } from './sim-options';
import './components'; // register all built-in plugins

// ===== ERC (Electrical Rule Check) =====
// Backward-compatible wrapper around the new full ERC engine in `erc.ts`.
// Use `runFullERC` directly for the full pin-conflict matrix + no-connect honor.

export type ERCError = import('./erc').ERCError;
export type ERCResult = import('./erc').ERCResult;

/** @deprecated use runFullERC for the complete rule set */
export function runERC(components: CircuitComponent[], wires: Wire[]): ERCResult {
  return runFullERC(components, wires, []);
}

// ===== Selection / Probe types =====

export interface Selection {
  type: 'component' | 'wire' | 'drawing' | 'group' | 'sheet' | null;
  id: string | null;
}

export interface ProbeSample {
  time: number;
  voltage: number;
}

export interface ProbeTrace {
  componentId: string;
  color: string;
  label: string;
  samples: ProbeSample[];
}

interface EditorState {
  // document
  components: CircuitComponent[];
  wires: Wire[];
  // selection (single)
  selection: Selection;
  // multi-selection
  multiSelection: { components: Set<string>; wires: Set<string> };
  // clipboard
  clipboard: { components: CircuitComponent[]; wires: Wire[] } | null;
  // ERC results
  ercErrors: ERCError[];
  // simulation settings
  running: boolean;
  speed: number;          // multiplier (1 = real-time at chosen dt)
  dt: number;             // timestep in seconds
  // current sim context (read-only mirror)
  simContext: SimContext | null;
  // simulation error message (null = no error). Set when solver fails.
  simError: string | null;
  // physics validation results (debug — catches simulation bugs)
  physicsViolations: PhysicsViolation[];
  // probe traces (per oscilloscope)
  traces: ProbeTrace[];
  maxTraceSamples: number;
  // history
  past: { components: CircuitComponent[]; wires: Wire[] }[];
  future: { components: CircuitComponent[]; wires: Wire[] }[];
  // ui
  paused: boolean;
  showGrid: boolean;
  snapToGrid: boolean;
  // wire draft
  wireDraft: { from: { componentId: string; terminalId: string }; cursor: { x: number; y: number } } | null;

  // ── New KiCad-parity document state ──────────────────────────────────────
  sheets: HierarchicalSheet[];
  netClasses: NetClass[];
  drawings: DrawingPrimitive[];
  noConnects: NoConnectMarker[];
  groups: Group[];
  pageSetup: PageSetup;
  savedViews: SavedView[];
  childSheets: Record<string, CircuitDocument>;
  activeSheet: string;
  metadata: {
    title?: string;
    company?: string;
    revision?: string;
    date?: string;
    author?: string;
  };

  // ── Display / units / view state ──────────────────────────────────────────
  units: 'mm' | 'mil' | 'in' | 'grid';
  gridSize: number;             // grid spacing in grid units
  showPinNumbers: boolean;
  showPinNames: boolean;
  showPinElecTypes: boolean;
  showRefdes: boolean;
  showValues: boolean;
  showTitleBlock: boolean;
  /** UI theme: 'dark' (default) or 'light' */
  theme: 'dark' | 'light';
  /** Customizable hotkeys (overrides defaults). Keys are hotkey names, values are key strings. */
  customHotkeys: Record<string, string>;
  activeTool: 'select' | 'wire' | 'bus' | 'label' | 'globalLabel' | 'hierLabel' | 'junction' | 'noConnect' | 'powerPort' | 'text' | 'line' | 'poly' | 'image';

  // actions
  addComponent: (type: string, position: { x: number; y: number }) => string;
  moveComponent: (id: string, position: { x: number; y: number }) => void;
  rotateComponent: (id: string) => void;
  /** Free rotation: rotate by arbitrary degrees (snapped to 15° increments). Stored as degrees. */
  rotateComponentFree: (id: string, degrees: number) => void;
  mirrorComponent: (id: string, axis: 'x' | 'y') => void;
  /** Toggle De Morgan alternate body style (convert 1 ↔ 2). No-op if plugin has no alternate body. */
  toggleDeMorgan: (id: string) => void;
  /** Swap two pins within a pin-swap group. Returns true if swap was legal. */
  swapPins: (id: string, pinIdA: string, pinIdB: string) => boolean;
  deleteComponent: (id: string) => void;
  deleteWire: (id: string) => void;
  setParameter: (id: string, key: string, value: number | string | boolean) => void;
  setSelection: (sel: Selection) => void;
  // multi-selection
  toggleMultiSelect: (type: 'component' | 'wire', id: string) => void;
  setMultiSelection: (sel: { components: Set<string>; wires: Set<string> }) => void;
  clearMultiSelection: () => void;
  moveSelectedComponents: (delta: { x: number; y: number }) => void;
  deleteSelected: () => void;
  mirrorSelected: (axis: 'x' | 'y') => void;
  rotateSelected: () => void;
  // copy/paste
  copySelection: () => void;
  paste: () => void;
  duplicate: () => void;
  // ERC
  runERC: () => ERCResult;
  runFullERCCheck: () => ERCResult;
  // annotation
  reannotate: () => void;
  reannotateByPosition: () => void;
  // fields
  setField: (compId: string, key: string, name: string, value: string, visible?: boolean) => void;
  removeField: (compId: string, key: string) => void;
  // lock
  toggleLock: (compId: string) => void;
  lockSelected: () => void;
  unlockSelected: () => void;
  // multi-unit
  setComponentUnit: (compId: string, unit: number) => void;
  setComponentConvert: (compId: string, convert: 1 | 2) => void;
  // net classes
  addNetClass: (name: string, description?: string) => string;
  updateNetClass: (id: string, patch: Partial<NetClass>) => void;
  removeNetClass: (id: string) => void;
  // drawings
  addDrawing: (d: DrawingPrimitive) => void;
  updateDrawing: (id: string, patch: Partial<DrawingPrimitive>) => void;
  removeDrawing: (id: string) => void;
  // no-connects
  addNoConnect: (componentId: string, terminalId: string) => void;
  removeNoConnect: (componentId: string, terminalId: string) => void;
  // groups
  createGroup: (name: string, componentIds: string[], wireIds?: string[], drawingIds?: string[]) => string;
  ungroup: (groupId: string) => void;
  // sheets
  addSheet: (sheetName: string, fileName: string) => string;
  removeSheet: (id: string) => void;
  setActiveSheet: (fileName: string) => void;
  /** Move a sheet box on the canvas (drag). Position is in grid coords. */
  moveSheet: (id: string, position: { x: number; y: number }) => void;
  /** Add a sheet pin to a sheet box. Auto-places on the right side if no side given. */
  addSheetPin: (sheetId: string, name: string, side?: 'top' | 'bottom' | 'left' | 'right') => string;
  /** Rename a sheet pin. */
  renameSheetPin: (sheetId: string, pinId: string, name: string) => void;
  /** Remove a sheet pin. */
  removeSheetPin: (sheetId: string, pinId: string) => void;
  /** Move a sheet pin to a new position (in grid coords, relative to sheet box). */
  moveSheetPin: (sheetId: string, pinId: string, position: { x: number; y: number }) => void;
  // saved views
  saveView: (name: string, camera: { x: number; y: number; zoom: number }) => string;
  loadView: (id: string) => SavedView | null;
  removeSavedView: (id: string) => void;
  // page setup
  setPageSetup: (patch: Partial<PageSetup>) => void;
  setMetadata: (patch: Partial<{ title: string; company: string; revision: string; date: string; author: string }>) => void;
  // display settings
  setUnits: (u: 'mm' | 'mil' | 'in' | 'grid') => void;
  setGridSize: (s: number) => void;
  setShowPinNumbers: (s: boolean) => void;
  setShowPinNames: (s: boolean) => void;
  setShowPinElecTypes: (s: boolean) => void;
  setShowRefdes: (s: boolean) => void;
  setShowValues: (s: boolean) => void;
  setShowTitleBlock: (s: boolean) => void;
  setTheme: (t: 'dark' | 'light') => void;
  setHotkey: (name: string, key: string) => void;
  resetHotkeys: () => void;
  setActiveTool: (t: EditorState['activeTool']) => void;
  // wire ops
  startWire: (from: { componentId: string; terminalId: string }, cursor: { x: number; y: number }) => void;
  updateWireCursor: (cursor: { x: number; y: number }) => void;
  cancelWire: () => void;
  completeWire: (to: { componentId: string; terminalId: string }) => void;
  setWireWaypoints: (id: string, waypoints: { x: number; y: number }[]) => void;
  toggleSwitch: (id: string) => void;
  // find/replace
  findComponents: (query: string, opts?: { searchRefdes?: boolean; searchValue?: boolean; searchFields?: boolean; caseSensitive?: boolean }) => CircuitComponent[];
  replaceComponentParameter: (compId: string, key: string, newValue: string | number | boolean) => void;

  undo: () => void;
  redo: () => void;
  pushHistory: () => void;
  clear: () => void;
  loadDocument: (doc: CircuitDocument) => void;
  serialize: () => CircuitDocument;

  setRunning: (running: boolean) => void;
  setSpeed: (s: number) => void;
  setDt: (dt: number) => void;
  step: () => void;
  reset: () => void;
  setShowGrid: (s: boolean) => void;
  setSnapToGrid: (s: boolean) => void;

  // ── Advanced analysis (KiCad ngspice parity) ──────────────────────────────
  /** last analysis result (AC/DC sweep/TF/etc.) — null if none yet */
  lastAnalysisResult: AnalysisResult | null;
  /** sim options — exposed to UI */
  simOptions: SimOptions;
  /** run an analysis (AC/DC/TF/etc.) and store result */
  runAnalysis: (config: AnalysisConfig) => AnalysisResult;
  /** run a batch sweep (.step / .mc / .worst) */
  runBatch: (config: BatchConfig) => BatchResult;
  /** run a .meas post-process on a trace */
  runMeasurement: (cmd: MeasCommand, trace: MeasRealTrace) => MeasResult;
  /** update sim options (reltol, gmin, method, temp, etc.) */
  setSimOptions: (patch: Partial<SimOptions>) => void;
  /** robust DC operating point using convergence aids */
  solveDCRobust: () => { sim: SimContext | null; report: ConvergenceReport };
}

let idCounter = 0;
function genId(prefix: string = 'c') {
  idCounter++;
  return `${prefix}_${Date.now().toString(36)}_${idCounter}`;
}

/** Get the reference designator prefix for a component type */
function refdesPrefix(type: string): string {
  switch (type) {
    case 'resistor': return 'R';
    case 'capacitor': return 'C';
    case 'inductor': return 'L';
    case 'led': return 'LED';
    case 'diode': return 'D';
    case 'zener': return 'DZ';
    case 'schottky': return 'D';
    case 'dcVoltage':
    case 'acVoltage':
    case 'pulseSource': return 'V';
    case 'currentSource': return 'I';
    case 'timer555':
    case 'opamp':
    case 'opampRails':
    case 'voltageRegulator':
    case 'vco': return 'U';
    case 'npn':
    case 'pnp':
    case 'nmos':
    case 'pmos': return 'Q';
    case 'switch':
    case 'pushButton': return 'SW';
    case 'fuse': return 'F';
    case 'crystal': return 'Y';
    case 'transformer': return 'T';
    case 'speaker':
    case 'buzzer': return 'LS';
    case 'dcMotor': return 'M';
    case 'photoresistor': return 'LDR';
    case 'sevenSegment': return 'DSP';
    case 'ground':
    case 'powerGND': return 'GND';
    case 'junction': return 'J';
    case 'oscilloscope':
    case 'voltmeter':
    case 'ammeter': return 'TP';
    case 'arduino':
    case 'arduinoReal':
    case 'raspberryPi': return 'U';
    case 'netLabel':
    case 'busLabel': return 'NL';
    case 'bus': return 'BUS';
    default:
      if (type.startsWith('7400_') || type.startsWith('7402_') || type.startsWith('7404_') ||
          type.startsWith('7408_') || type.startsWith('7432_') || type.startsWith('7486_') ||
          type.startsWith('7474_')) return 'U';
      if (type.startsWith('custom_')) return 'U';
      return 'U';
  }
}

/** Generate the next refdes for a given type, based on existing components */
function nextRefdes(type: string, components: CircuitComponent[]): string {
  const prefix = refdesPrefix(type);
  let maxNum = 0;
  for (const c of components) {
    if (refdesPrefix(c.type) === prefix) {
      const ref = c.refdes ?? c.id;
      const match = ref.match(/(\d+)$/);
      if (match) {
        const n = parseInt(match[1]);
        if (n > maxNum) maxNum = n;
      }
    }
  }
  return `${prefix}${maxNum + 1}`;
}

function snapshot(s: {
  components: CircuitComponent[];
  wires: Wire[];
  drawings?: DrawingPrimitive[];
  noConnects?: NoConnectMarker[];
  groups?: Group[];
  sheets?: HierarchicalSheet[];
  netClasses?: NetClass[];
}) {
  return {
    components: s.components.map((c) => ({ ...c, parameters: { ...c.parameters }, simState: undefined, fields: c.fields ? c.fields.map((f) => ({ ...f })) : undefined })),
    wires: s.wires.map((w) => ({ ...w })),
    drawings: s.drawings ? s.drawings.map((d) => ({ ...d })) : [],
    noConnects: s.noConnects ? s.noConnects.map((n) => ({ ...n })) : [],
    groups: s.groups ? s.groups.map((g) => ({ ...g, componentIds: [...g.componentIds], wireIds: [...g.wireIds], drawingIds: [...g.drawingIds] })) : [],
    sheets: s.sheets ? s.sheets.map((sh) => ({ ...sh, pins: sh.pins.map((p) => ({ ...p })) })) : [],
    netClasses: s.netClasses ? s.netClasses.map((nc) => ({ ...nc, nets: [...nc.nets] })) : [],
  };
}

const MAX_HISTORY = 100;

// helper: get plugin defaults
function defaultsFor(type: string): Record<string, number | string | boolean> {
  const plugin = getPlugin(type);
  if (!plugin) return {};
  const defaults: Record<string, number | string | boolean> = {};
  for (const p of plugin.parameters) defaults[p.key] = p.default;
  return defaults;
}

export const useEditor = create<EditorState>((set, get) => ({
  components: [],
  wires: [],
  selection: { type: null, id: null },
  multiSelection: { components: new Set(), wires: new Set() },
  clipboard: null,
  ercErrors: [],
  running: false,
  speed: 1,
  dt: 1e-4,
  simContext: null,
  simError: null,
  physicsViolations: [],
  traces: [],
  maxTraceSamples: 500,
  past: [],
  future: [],
  paused: true,
  showGrid: true,
  snapToGrid: true,
  wireDraft: null,
  // new doc state
  sheets: [],
  netClasses: [],
  drawings: [],
  noConnects: [],
  groups: [],
  pageSetup: { ...DEFAULT_PAGE_SETUP },
  savedViews: [],
  childSheets: {},
  activeSheet: '',
  metadata: { title: 'Untitled', revision: 'Rev 1', date: new Date().toISOString().slice(0, 10) },
  // display
  units: 'grid',
  gridSize: 1,
  showPinNumbers: false,
  showPinNames: false,
  showPinElecTypes: false,
  showRefdes: true,
  showValues: true,
  showTitleBlock: false,
  theme: 'dark',
  customHotkeys: {},
  activeTool: 'select',

  addComponent: (type, position) => {
    get().pushHistory();
    const id = genId('comp');
    const s = get();
    const refdes = nextRefdes(type, s.components);
    const comp: CircuitComponent = {
      id,
      type,
      position: { ...position },
      rotation: 0,
      parameters: defaultsFor(type),
      refdes,
    };
    set((s) => ({ components: [...s.components, comp], selection: { type: 'component', id } }));
    return id;
  },

  moveComponent: (id, position) => {
    set((s) => ({
      components: s.components.map((c) =>
        c.id === id ? { ...c, position: { ...position } } : c,
      ),
    }));
  },

  rotateComponent: (id) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) =>
        c.id === id
          ? { ...c, rotation: (((c.rotation + 1) % 4) as 0 | 1 | 2 | 3) }
          : c,
      ),
    }));
  },

  mirrorComponent: (id, axis) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) =>
        c.id === id
          ? { ...c, [axis === 'x' ? 'mirrorX' : 'mirrorY']: !c[axis === 'x' ? 'mirrorX' : 'mirrorY'] }
          : c,
      ),
    }));
  },

  rotateComponentFree: (id, degrees) => {
    // Snap to 15° increments (24 distinct angles). Stored in `rotationDeg`.
    // The canvas's render loop should use rotationDeg if present, otherwise fall back to rotation*90.
    get().pushHistory();
    const snapped = Math.round(degrees / 15) * 15;
    set((s) => ({
      components: s.components.map((c) =>
        c.id === id ? { ...c, rotationDeg: snapped } : c,
      ),
    }));
  },

  toggleDeMorgan: (id) => {
    const comp = get().components.find((c) => c.id === id);
    if (!comp) return;
    const plugin = getPlugin(comp.type);
    if (!plugin?.hasAlternateBody) return;
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) =>
        c.id === id ? { ...c, convert: c.convert === 2 ? 1 : 2 } : c,
      ),
    }));
  },

  swapPins: (id, pinIdA, pinIdB) => {
    const comp = get().components.find((c) => c.id === id);
    if (!comp) return false;
    const plugin = getPlugin(comp.type);
    if (!plugin?.pinSwapGroups) return false;
    // Check if both pins are in the same swap group
    const inSameGroup = plugin.pinSwapGroups.some((group) =>
      group.includes(pinIdA) && group.includes(pinIdB),
    );
    if (!inSameGroup) return false;
    // Swap: we re-emit all wires that referenced pinIdA to pinIdB and vice versa.
    // This requires walking the wires array and swapping terminal IDs.
    get().pushHistory();
    set((s) => ({
      wires: s.wires.map((w) => {
        if (w.from.componentId === id && w.from.terminalId === pinIdA) {
          return { ...w, from: { ...w.from, terminalId: pinIdB } };
        }
        if (w.from.componentId === id && w.from.terminalId === pinIdB) {
          return { ...w, from: { ...w.from, terminalId: pinIdA } };
        }
        if (w.to.componentId === id && w.to.terminalId === pinIdA) {
          return { ...w, to: { ...w.to, terminalId: pinIdB } };
        }
        if (w.to.componentId === id && w.to.terminalId === pinIdB) {
          return { ...w, to: { ...w.to, terminalId: pinIdA } };
        }
        return w;
      }),
    }));
    return true;
  },

  deleteComponent: (id) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.filter((c) => c.id !== id),
      wires: s.wires.filter((w) => w.from.componentId !== id && w.to.componentId !== id),
      selection: { type: null, id: null },
      traces: s.traces.filter((t) => t.componentId !== id),
    }));
  },

  deleteWire: (id) => {
    get().pushHistory();
    set((s) => ({
      wires: s.wires.filter((w) => w.id !== id),
      selection: { type: null, id: null },
    }));
  },

  setParameter: (id, key, value) => {
    // KiCad parity: parameter edits must be undoable. Coalesce rapid edits into a single history entry.
    const s = get();
    const last = s.past[s.past.length - 1];
    const isCoalescing = last &&
      (last as any).__paramEdit?.id === id &&
      (last as any).__paramEdit?.key === key &&
      Date.now() - ((last as any).__paramEdit?.ts ?? 0) < 1500;
    if (!isCoalescing) {
      get().pushHistory();
      // mark the snapshot as a param-edit so subsequent edits to same param can coalesce
      const cur = get();
      if (cur.past.length > 0) {
        (cur.past[cur.past.length - 1] as any).__paramEdit = { id, key, ts: Date.now() };
      }
    }
    set((s) => ({
      components: s.components.map((c) =>
        c.id === id ? { ...c, parameters: { ...c.parameters, [key]: value } } : c,
      ),
    }));
  },

  setSelection: (sel) => set({ selection: sel, multiSelection: { components: new Set(), wires: new Set() } }),

  // ===== Multi-selection =====
  toggleMultiSelect: (type, id) => {
    set((s) => {
      const ms = {
        components: new Set(s.multiSelection.components),
        wires: new Set(s.multiSelection.wires),
      };
      if (type === 'component') {
        if (ms.components.has(id)) ms.components.delete(id);
        else ms.components.add(id);
      } else {
        if (ms.wires.has(id)) ms.wires.delete(id);
        else ms.wires.add(id);
      }
      return { multiSelection: ms };
    });
  },
  setMultiSelection: (sel) => set({ multiSelection: sel, selection: { type: null, id: null } }),
  clearMultiSelection: () => set({ multiSelection: { components: new Set(), wires: new Set() } }),

  moveSelectedComponents: (delta) => {
    set((s) => {
      const ids = new Set(s.multiSelection.components);
      if (s.selection.type === 'component' && s.selection.id) ids.add(s.selection.id);
      if (ids.size === 0) return {};
      return {
        components: s.components.map((c) =>
          ids.has(c.id) ? { ...c, position: { x: c.position.x + delta.x, y: c.position.y + delta.y } } : c,
        ),
      };
    });
  },

  deleteSelected: () => {
    get().pushHistory();
    set((s) => {
      const idsToDelete = new Set(s.multiSelection.components);
      if (s.selection.type === 'component' && s.selection.id) idsToDelete.add(s.selection.id);
      const wiresToDelete = new Set(s.multiSelection.wires);
      if (s.selection.type === 'wire' && s.selection.id) wiresToDelete.add(s.selection.id);
      return {
        components: s.components.filter((c) => !idsToDelete.has(c.id)),
        wires: s.wires.filter((w) => !wiresToDelete.has(w.id) &&
          !idsToDelete.has(w.from.componentId) && !idsToDelete.has(w.to.componentId)),
        selection: { type: null, id: null },
        multiSelection: { components: new Set(), wires: new Set() },
      };
    });
  },

  // ===== Copy/Paste =====
  copySelection: () => {
    const s = get();
    const idsToCopy = new Set(s.multiSelection.components);
    if (s.selection.type === 'component' && s.selection.id) idsToCopy.add(s.selection.id);
    if (idsToCopy.size === 0) return;
    const copiedComponents = s.components
      .filter((c) => idsToCopy.has(c.id))
      .map((c) => ({ ...c, parameters: { ...c.parameters }, simState: undefined }));
    const copiedWires = s.wires
      .filter((w) => idsToCopy.has(w.from.componentId) && idsToCopy.has(w.to.componentId))
      .map((w) => ({ ...w }));
    set({ clipboard: { components: copiedComponents, wires: copiedWires } });
  },

  paste: () => {
    const s = get();
    if (!s.clipboard || s.clipboard.components.length === 0) return;
    get().pushHistory();
    const idMap = new Map<string, string>();
    const newComponents = s.clipboard.components.map((c) => {
      const newId = genId('comp');
      idMap.set(c.id, newId);
      return { ...c, id: newId, position: { x: c.position.x + 2, y: c.position.y + 2 }, parameters: { ...c.parameters }, simState: undefined };
    });
    const newWires = s.clipboard.wires.map((w) => ({
      id: genId('wire'),
      from: { componentId: idMap.get(w.from.componentId) ?? w.from.componentId, terminalId: w.from.terminalId },
      to: { componentId: idMap.get(w.to.componentId) ?? w.to.componentId, terminalId: w.to.terminalId },
    }));
    set((st) => ({
      components: [...st.components, ...newComponents],
      wires: [...st.wires, ...newWires],
      selection: { type: null, id: null },
      multiSelection: {
        components: new Set(newComponents.map((c) => c.id)),
        wires: new Set(newWires.map((w) => w.id)),
      },
    }));
  },

  duplicate: () => { get().copySelection(); get().paste(); },

  // ===== ERC =====
  runERC: () => {
    const s = get();
    const result = runERC(s.components, s.wires);
    set({ ercErrors: result.errors });
    return result;
  },

  runFullERCCheck: () => {
    const s = get();
    // Run ERC across the flattened hierarchy so cross-sheet errors are caught
    let ercComponents = s.components;
    let ercWires = s.wires;
    if (s.activeSheet || s.sheets.length > 0) {
      let childSheets = s.childSheets;
      if (s.activeSheet) {
        childSheets = {
          ...childSheets,
          [s.activeSheet]: snapshotSheet(s.components, s.wires, s.sheets),
        };
      }
      const rootDoc = s.activeSheet
        ? (childSheets as any).__root__ ?? { version: 1 as const, components: [], wires: [], sheets: [] }
        : { version: 1 as const, components: s.components, wires: s.wires, sheets: s.sheets };
      const flat = flattenHierarchy(rootDoc as any, childSheets as any);
      ercComponents = flat.components;
      ercWires = flat.wires;
    }
    const result = runFullERC(ercComponents, ercWires, s.noConnects);
    set({ ercErrors: result.errors });
    return result;
  },

  reannotate: () => {
    get().pushHistory();
    const s = get();
    const counters: Record<string, number> = {};
    const newComponents = s.components.map((c) => {
      const prefix = refdesPrefix(c.type);
      counters[prefix] = (counters[prefix] ?? 0) + 1;
      return { ...c, refdes: `${prefix}${counters[prefix]}` };
    });
    set({ components: newComponents });
  },

  // KiCad parity: annotate by X-then-Y position (left-to-right, top-to-bottom)
  reannotateByPosition: () => {
    get().pushHistory();
    const s = get();
    // stable sort: y asc (top first), then x asc (left first)
    const sorted = [...s.components].sort((a, b) => {
      if (Math.abs(a.position.y - b.position.y) > 0.5) return a.position.y - b.position.y;
      return a.position.x - b.position.x;
    });
    const counters: Record<string, number> = {};
    const updates = new Map<string, string>();
    for (const c of sorted) {
      const prefix = refdesPrefix(c.type);
      counters[prefix] = (counters[prefix] ?? 0) + 1;
      updates.set(c.id, `${prefix}${counters[prefix]}`);
    }
    set({
      components: s.components.map((c) => updates.has(c.id) ? { ...c, refdes: updates.get(c.id)! } : c),
    });
  },

  // ===== Component fields (KiCad "Fields" tab) =====
  setField: (compId, key, name, value, visible = true) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) => {
        if (c.id !== compId) return c;
        const fields = c.fields ? [...c.fields] : [];
        const idx = fields.findIndex((f) => f.key === key);
        if (idx >= 0) fields[idx] = { ...fields[idx], name, value, visible };
        else fields.push({ key, name, value, visible });
        return { ...c, fields };
      }),
    }));
  },
  removeField: (compId, key) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) => {
        if (c.id !== compId || !c.fields) return c;
        return { ...c, fields: c.fields.filter((f) => f.key !== key) };
      }),
    }));
  },

  // ===== Lock =====
  toggleLock: (compId) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) =>
        c.id === compId ? { ...c, locked: !c.locked } : c,
      ),
    }));
  },
  lockSelected: () => {
    get().pushHistory();
    set((s) => {
      const ids = new Set(s.multiSelection.components);
      if (s.selection.type === 'component' && s.selection.id) ids.add(s.selection.id);
      return {
        components: s.components.map((c) => ids.has(c.id) ? { ...c, locked: true } : c),
      };
    });
  },
  unlockSelected: () => {
    get().pushHistory();
    set((s) => {
      const ids = new Set(s.multiSelection.components);
      if (s.selection.type === 'component' && s.selection.id) ids.add(s.selection.id);
      return {
        components: s.components.map((c) => ids.has(c.id) ? { ...c, locked: false } : c),
      };
    });
  },

  // ===== Multi-unit components =====
  setComponentUnit: (compId, unit) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) =>
        c.id === compId ? { ...c, unit } : c,
      ),
    }));
  },
  setComponentConvert: (compId, convert) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) =>
        c.id === compId ? { ...c, convert } : c,
      ),
    }));
  },

  // ===== Mirror/Rotate selection =====
  mirrorSelected: (axis) => {
    get().pushHistory();
    set((s) => {
      const ids = new Set(s.multiSelection.components);
      if (s.selection.type === 'component' && s.selection.id) ids.add(s.selection.id);
      const field = axis === 'x' ? 'mirrorX' : 'mirrorY';
      return {
        components: s.components.map((c) =>
          ids.has(c.id) ? { ...c, [field]: !c[field] } : c,
        ),
      };
    });
  },
  rotateSelected: () => {
    get().pushHistory();
    set((s) => {
      const ids = new Set(s.multiSelection.components);
      if (s.selection.type === 'component' && s.selection.id) ids.add(s.selection.id);
      return {
        components: s.components.map((c) =>
          ids.has(c.id) ? { ...c, rotation: (((c.rotation + 1) % 4) as 0 | 1 | 2 | 3) } : c,
        ),
      };
    });
  },

  // ===== Net classes =====
  addNetClass: (name, description) => {
    const id = genId('nc');
    set((s) => ({
      netClasses: [...s.netClasses, { id, name, description: description ?? '', nets: [], color: '#22d3ee' }],
    }));
    return id;
  },
  updateNetClass: (id, patch) => {
    get().pushHistory();
    set((s) => ({
      netClasses: s.netClasses.map((nc) => nc.id === id ? { ...nc, ...patch } : nc),
    }));
  },
  removeNetClass: (id) => {
    get().pushHistory();
    set((s) => ({
      netClasses: s.netClasses.filter((nc) => nc.id !== id),
      components: s.components.map((c) => c.netClassId === id ? { ...c, netClassId: undefined } : c),
    }));
  },

  // ===== Drawings =====
  addDrawing: (d) => {
    get().pushHistory();
    set((s) => ({ drawings: [...s.drawings, d] }));
  },
  updateDrawing: (id, patch) => {
    set((s) => ({
      drawings: s.drawings.map((d) => d.id === id ? { ...d, ...patch } as DrawingPrimitive : d),
    }));
  },
  removeDrawing: (id) => {
    get().pushHistory();
    set((s) => ({ drawings: s.drawings.filter((d) => d.id !== id) }));
  },

  // ===== No-Connect markers =====
  addNoConnect: (componentId, terminalId) => {
    get().pushHistory();
    set((s) => ({
      noConnects: s.noConnects.filter((n) => !(n.componentId === componentId && n.terminalId === terminalId)),
    }));
    set((s) => ({
      noConnects: [...s.noConnects, { id: genId('nc'), componentId, terminalId }],
    }));
  },
  removeNoConnect: (componentId, terminalId) => {
    get().pushHistory();
    set((s) => ({
      noConnects: s.noConnects.filter((n) => !(n.componentId === componentId && n.terminalId === terminalId)),
    }));
  },

  // ===== Groups =====
  createGroup: (name, componentIds, wireIds = [], drawingIds = []) => {
    const id = genId('grp');
    get().pushHistory();
    set((s) => ({
      groups: [...s.groups, { id, name, componentIds: [...componentIds], wireIds: [...wireIds], drawingIds: [...drawingIds] }],
    }));
    return id;
  },
  ungroup: (groupId) => {
    get().pushHistory();
    set((s) => ({ groups: s.groups.filter((g) => g.id !== groupId) }));
  },

  // ===== Hierarchical sheets =====
  addSheet: (sheetName, fileName) => {
    const id = genId('sheet');
    get().pushHistory();
    set((s) => ({
      sheets: [...s.sheets, {
        id, sheetName, fileName,
        position: { x: 20, y: 10 },
        size: { width: 10, height: 6 },
        pins: [],
      }],
      childSheets: { ...s.childSheets, [fileName]: { version: 1, components: [], wires: [] } },
    }));
    return id;
  },
  removeSheet: (id) => {
    get().pushHistory();
    set((s) => {
      const sheet = s.sheets.find((sh) => sh.id === id);
      const newChild = { ...s.childSheets };
      if (sheet) delete newChild[sheet.fileName];
      return {
        sheets: s.sheets.filter((sh) => sh.id !== id),
        childSheets: newChild,
      };
    });
  },
  setActiveSheet: (fileName) => {
    const s = get();
    // Snapshot the current sheet into childSheets (or root, kept implicitly as the
    // active components/wires when activeSheet === '').
    const currentSheetFileName = s.activeSheet;
    if (currentSheetFileName) {
      // Save the current sheet's contents back to childSheets[currentSheetFileName]
      const snap = snapshotSheet(s.components, s.wires, s.sheets);
      set((st) => ({
        childSheets: {
          ...st.childSheets,
          [currentSheetFileName]: snap,
        },
      }));
    } else {
      // We were on root — root's components/wires stay in place (no swap needed
      // when navigating back to root, just restore the saved snapshot below
      // when going elsewhere).
    }

    if (!fileName) {
      // Navigating back to root — restore root's saved snapshot if we have one.
      // Root's components/wires are kept as the "current" state when on root,
      // so if we're already on root there's nothing to do. If we're returning
      // from a sub-sheet, the root snapshot is in `childSheets['__root__']`
      // (a special key we use to preserve root state across sub-sheet edits).
      const rootSnap = (s.childSheets as any)['__root__'];
      if (rootSnap) {
        set({
          activeSheet: '',
          components: rootSnap.components,
          wires: rootSnap.wires,
          sheets: rootSnap.sheets ?? [],
        });
        // Remove the temporary __root__ key
        const newChild = { ...get().childSheets };
        delete (newChild as any)['__root__'];
        set({ childSheets: newChild });
      } else {
        set({ activeSheet: '' });
      }
      return;
    }

    // Save current root state into __root__ if we're leaving root
    if (!currentSheetFileName) {
      const rootSnap = snapshotSheet(s.components, s.wires, s.sheets);
      set((st) => ({
        childSheets: {
          ...st.childSheets,
          __root__: rootSnap as any,
        },
      }));
    }

    // Switch to the target sub-sheet
    const targetDoc = get().childSheets[fileName];
    if (targetDoc) {
      set({
        activeSheet: fileName,
        components: targetDoc.components ?? [],
        wires: targetDoc.wires ?? [],
        sheets: (targetDoc as any).sheets ?? [],
      });
    } else {
      // Sub-sheet doesn't exist yet — create an empty one
      set({
        activeSheet: fileName,
        components: [],
        wires: [],
        sheets: [],
      });
    }
  },

  moveSheet: (id, position) => {
    get().pushHistory();
    set((s) => ({
      sheets: s.sheets.map((sh) => sh.id === id ? { ...sh, position } : sh),
    }));
  },

  addSheetPin: (sheetId, name, side = 'right') => {
    const id = genId('pin');
    get().pushHistory();
    set((s) => ({
      sheets: s.sheets.map((sh) => {
        if (sh.id !== sheetId) return sh;
        // Auto-place on the chosen side
        const pinsOnSide = sh.pins.filter((p) => p.side === side);
        const idx = pinsOnSide.length + 1;
        let position: { x: number; y: number };
        switch (side) {
          case 'left':   position = { x: 0, y: idx }; break;
          case 'right':  position = { x: sh.size.width, y: idx }; break;
          case 'top':    position = { x: idx, y: 0 }; break;
          case 'bottom': position = { x: idx, y: sh.size.height }; break;
        }
        return {
          ...sh,
          pins: [...sh.pins, {
            id, name, electricalType: 'passive' as const,
            position, side,
          }],
        };
      }),
    }));
    return id;
  },

  renameSheetPin: (sheetId, pinId, name) => {
    get().pushHistory();
    set((s) => ({
      sheets: s.sheets.map((sh) => sh.id !== sheetId ? sh : {
        ...sh,
        pins: sh.pins.map((p) => p.id === pinId ? { ...p, name } : p),
      }),
    }));
  },

  removeSheetPin: (sheetId, pinId) => {
    get().pushHistory();
    set((s) => ({
      sheets: s.sheets.map((sh) => sh.id !== sheetId ? sh : {
        ...sh,
        pins: sh.pins.filter((p) => p.id !== pinId),
      }),
    }));
  },

  moveSheetPin: (sheetId, pinId, position) => {
    get().pushHistory();
    set((s) => ({
      sheets: s.sheets.map((sh) => sh.id !== sheetId ? sh : {
        ...sh,
        pins: sh.pins.map((p) => p.id === pinId ? { ...p, position } : p),
      }),
    }));
  },

  // ===== Saved views =====
  saveView: (name, camera) => {
    const id = genId('view');
    set((s) => ({ savedViews: [...s.savedViews, { id, name, camera }] }));
    return id;
  },
  loadView: (id) => {
    const s = get();
    return s.savedViews.find((v) => v.id === id) ?? null;
  },
  removeSavedView: (id) => {
    set((s) => ({ savedViews: s.savedViews.filter((v) => v.id !== id) }));
  },

  // ===== Page setup & metadata =====
  setPageSetup: (patch) => {
    get().pushHistory();
    set((s) => ({ pageSetup: { ...s.pageSetup, ...patch } }));
  },
  setMetadata: (patch) => {
    get().pushHistory();
    set((s) => ({ metadata: { ...s.metadata, ...patch } }));
  },

  // ===== Display =====
  setUnits: (u) => set({ units: u }),
  setGridSize: (s) => set({ gridSize: s }),
  setShowPinNumbers: (s) => set({ showPinNumbers: s }),
  setShowPinNames: (s) => set({ showPinNames: s }),
  setShowPinElecTypes: (s) => set({ showPinElecTypes: s }),
  setShowRefdes: (s) => set({ showRefdes: s }),
  setShowValues: (s) => set({ showValues: s }),
  setShowTitleBlock: (s) => set({ showTitleBlock: s }),
  setTheme: (t) => set({ theme: t }),
  setHotkey: (name, key) => set((s) => ({ customHotkeys: { ...s.customHotkeys, [name]: key } })),
  resetHotkeys: () => set({ customHotkeys: {} }),
  setActiveTool: (t) => set({ activeTool: t }),

  // ===== Find / Replace =====
  findComponents: (query, opts = {}) => {
    const s = get();
    if (!query) return [];
    const { searchRefdes = true, searchValue = true, searchFields = true, caseSensitive = false } = opts;
    const q = caseSensitive ? query : query.toLowerCase();
    return s.components.filter((c) => {
      if (searchRefdes) {
        const r = c.refdes ?? c.id;
        if ((caseSensitive ? r : r.toLowerCase()).includes(q)) return true;
      }
      if (searchValue) {
        for (const v of Object.values(c.parameters)) {
          const s = String(v);
          if ((caseSensitive ? s : s.toLowerCase()).includes(q)) return true;
        }
      }
      if (searchFields && c.fields) {
        for (const f of c.fields) {
          const combined = `${f.name}=${f.value}`;
          if ((caseSensitive ? combined : combined.toLowerCase()).includes(q)) return true;
        }
      }
      return false;
    });
  },
  replaceComponentParameter: (compId, key, newValue) => {
    get().pushHistory();
    set((s) => ({
      components: s.components.map((c) => {
        if (c.id !== compId) return c;
        const params = { ...c.parameters };
        // try to preserve type: if old was number, coerce newValue to number
        const old = params[key];
        if (typeof old === 'number') {
          const n = parseFloat(newValue as string);
          params[key] = isNaN(n) ? newValue : n;
        } else if (typeof old === 'boolean') {
          params[key] = (newValue === 'true' || newValue === true || newValue === '1');
        } else {
          params[key] = newValue;
        }
        return { ...c, parameters: params };
      }),
    }));
  },

  startWire: (from, cursor) => set({ wireDraft: { from, cursor } }),
  updateWireCursor: (cursor) => set((s) => (s.wireDraft ? { wireDraft: { ...s.wireDraft, cursor } } : {})),
  cancelWire: () => set({ wireDraft: null }),
  completeWire: (to) => {
    const draft = get().wireDraft;
    if (!draft) return;
    if (draft.from.componentId === to.componentId && draft.from.terminalId === to.terminalId) {
      set({ wireDraft: null });
      return;
    }
    get().pushHistory();
    const id = genId('wire');
    const wire: Wire = { id, from: draft.from, to };
    set((s) => ({ wires: [...s.wires, wire], wireDraft: null }));
  },

  setWireWaypoints: (id, waypoints) => {
    set((s) => ({
      wires: s.wires.map((w) => (w.id === id ? { ...w, waypoints: waypoints.length > 0 ? waypoints : undefined } : w)),
    }));
  },

  toggleSwitch: (id) => {
    set((s) => ({
      components: s.components.map((c) => {
        if (c.id !== id) return c;
        if (c.type === 'switch') return { ...c, parameters: { ...c.parameters, closed: !c.parameters.closed } };
        if (c.type === 'pushButton') return { ...c, parameters: { ...c.parameters, pressed: !c.parameters.pressed } };
        return c;
      }),
    }));
  },

  pushHistory: () => {
    set((s) => {
      const snap = snapshot(s);
      const past = [...s.past, snap].slice(-MAX_HISTORY);
      return { past, future: [] };
    });
  },

  undo: () => {
    set((s) => {
      if (s.past.length === 0) return {};
      const prev = s.past[s.past.length - 1];
      const current = snapshot(s);
      return {
        past: s.past.slice(0, -1),
        future: [current, ...s.future].slice(0, MAX_HISTORY),
        components: prev.components,
        wires: prev.wires,
        selection: { type: null, id: null },
      };
    });
  },

  redo: () => {
    set((s) => {
      if (s.future.length === 0) return {};
      const next = s.future[0];
      const current = snapshot(s);
      return {
        past: [...s.past, current].slice(-MAX_HISTORY),
        future: s.future.slice(1),
        components: next.components,
        wires: next.wires,
        selection: { type: null, id: null },
      };
    });
  },

  clear: () => {
    get().pushHistory();
    set({
      components: [],
      wires: [],
      drawings: [],
      noConnects: [],
      groups: [],
      sheets: [],
      netClasses: [],
      savedViews: [],
      childSheets: {},
      activeSheet: '',
      selection: { type: null, id: null },
      multiSelection: { components: new Set(), wires: new Set() },
      traces: [],
      simContext: null,
    });
  },

  loadDocument: (doc) => {
    set({
      components: doc.components.map((c) => ({ ...c, parameters: { ...c.parameters }, simState: undefined, fields: c.fields ? c.fields.map((f) => ({ ...f })) : undefined })),
      wires: doc.wires.map((w) => ({ ...w })),
      drawings: doc.drawings ?? [],
      noConnects: doc.noConnects ?? [],
      groups: doc.groups ?? [],
      sheets: doc.sheets ?? [],
      netClasses: doc.netClasses ?? [],
      savedViews: doc.savedViews ?? [],
      childSheets: doc.childSheets ?? {},
      activeSheet: doc.activeSheet ?? '',
      pageSetup: doc.pageSetup ?? { ...DEFAULT_PAGE_SETUP },
      metadata: doc.metadata ?? { title: 'Untitled', revision: 'Rev 1', date: new Date().toISOString().slice(0, 10) },
      selection: { type: null, id: null },
      multiSelection: { components: new Set(), wires: new Set() },
      traces: [],
      simContext: null,
      past: [],
      future: [],
    });
  },

  serialize: () => {
    const s = get();
    return {
      version: 1 as const,
      components: s.components.map((c) => ({ ...c, simState: undefined })),
      wires: s.wires.map((w) => ({ ...w })),
      drawings: s.drawings,
      noConnects: s.noConnects,
      groups: s.groups,
      sheets: s.sheets,
      netClasses: s.netClasses,
      savedViews: s.savedViews,
      childSheets: s.childSheets,
      activeSheet: s.activeSheet,
      pageSetup: s.pageSetup,
      metadata: s.metadata,
    };
  },

  setRunning: (running) => {
    if (running) {
      // Guard: refuse to start on empty circuit
      const s = get();
      if (s.components.length === 0 && s.sheets.length === 0) {
        set({ simError: 'Cannot start: circuit is empty. Add components first.' });
        return;
      }
      // Clear any previous error
      set({ running: true, paused: false, simError: null });
    } else {
      set({ running: false, paused: true });
    }
  },
  setSpeed: (speed) => set({ speed }),
  setDt: (dt) => set({ dt }),

  step: () => {
    const s = get();
    if (s.components.length === 0 && s.sheets.length === 0) return;

    try {

    // ── Cross-sheet simulation ────────────────────────────────────────────
    // If we're inside a sub-sheet OR the root has sub-sheets, we need to
    // flatten the hierarchy into a single (components, wires) pair before
    // simulating. We do this on every step so sub-sheet edits are picked up
    // immediately. The flattened components have prefixed IDs (e.g. "amp.R1")
    // so they don't collide with the active sheet's IDs.
    let simComponents = s.components;
    let simWires = s.wires;
    let usingHierarchy = false;
    if (s.activeSheet || s.sheets.length > 0) {
      usingHierarchy = true;
      // Save the current sheet back into childSheets so flattenHierarchy sees it
      let childSheets = s.childSheets;
      if (s.activeSheet) {
        childSheets = {
          ...childSheets,
          [s.activeSheet]: snapshotSheet(s.components, s.wires, s.sheets),
        };
      }
      // Build root document from either the active root state or the saved __root__
      const rootDoc = s.activeSheet
        ? (childSheets as any).__root__ ?? { version: 1 as const, components: [], wires: [], sheets: [] }
        : { version: 1 as const, components: s.components, wires: s.wires, sheets: s.sheets };
      const flat = flattenHierarchy(rootDoc as any, childSheets as any);
      simComponents = flat.components;
      simWires = flat.wires;
    }

    const plugins = new Map<string, any>();
    for (const c of simComponents) {
      const p = getPlugin(c.type);
      if (p) plugins.set(c.type, p);
    }
    // Keep a persistent state map across steps so capacitors/inductors/555 remember their state
    const persistentState = s.simContext?.state ?? {};
    const prev = s.simContext
      ? {
          nodeVoltage: s.simContext.nodeVoltage,
          branchCurrent: s.simContext.branchCurrent,
          time: s.simContext.time,
          state: persistentState,
        }
      : { nodeVoltage: new Float64Array(0), branchCurrent: new Float64Array(0), time: 0, state: persistentState };
    // run sub-steps based on speed
    // For speed >= 1: run floor(speed) sub-steps per frame (e.g., 4x = 4 steps)
    // For speed < 1: run 1 step every Nth frame, where N = ceil(1/speed)
    //   This is tracked via simStepCounter in the store state
    const speed = s.speed;
    let subSteps: number;
    if (speed >= 1) {
      subSteps = Math.max(1, Math.floor(speed));
    } else {
      // Sub-real-time: skip steps to slow down the simulation
      const skipInterval = Math.ceil(1 / speed); // e.g., 0.5x → skip every 2nd frame
      const stepCount = (s as any).__stepCount ?? 0;
      (s as any).__stepCount = stepCount + 1;
      if (stepCount % skipInterval !== 0) {
        return; // skip this frame to slow down
      }
      subSteps = 1;
    }
    const dt = s.dt;
    // Build simOptions from the editor's settings (temperature, .IC, .NODESET)
    const simOpts = {
      initialConditions: s.simOptions?.initialConditions,
      nodeSets: s.simOptions?.nodeSets,
    };
    let result: { sim: SimContext; branchCurrentSize: number; nodeMap: any } | null = null;
    for (let i = 0; i < subSteps; i++) {
      result = simulateStep(simComponents, simWires, plugins, prev, dt, simOpts);
      if (!result) break;
      prev.nodeVoltage = result.sim.nodeVoltage;
      prev.branchCurrent = result.sim.branchCurrent;
      prev.time = result.sim.time;
      prev.state = result.sim.state;

      // Digital fast-forward: advance sim.time toward the next clock edge.
      // Handles two types of clock sources:
      //   1. pulseSource (crystal) — when no capacitors/inductors present
      //   2. timer555 in astable mode — computes output from sim.time + R/C params
      // Without fast-forward, a 1Hz clock would take ~10000 steps per cycle.
      const hasCapacitor = simComponents.some(c => c.type === 'capacitor' || c.type === 'inductor');
      const hasPulseSource = simComponents.some(c => c.type === 'pulseSource');
      const hasArduino = simComponents.some(c => c.type === 'arduinoReal' || c.type === 'arduino');
      const hasAstable555 = simComponents.some(c =>
        c.type === 'timer555' && (c.parameters.astable as boolean) === true);

      // Compute the minimum clock frequency across all digital clock sources
      let minFreq = Infinity;

      // Pulse sources
      if (hasPulseSource && !hasCapacitor && !hasArduino) {
        for (const c of simComponents) {
          if (c.type === 'pulseSource') {
            const f = c.parameters.frequency as number;
            if (f > 0 && f < minFreq) minFreq = f;
          }
        }
      }

      // Astable 555 timers: frequency = 1 / (0.693 * (R1 + 2*R2) * C)
      if (hasAstable555) {
        for (const c of simComponents) {
          if (c.type === 'timer555' && (c.parameters.astable as boolean) === true) {
            const r1 = (c.parameters.r1 as number) || 47000;
            const r2 = (c.parameters.r2 as number) || 47000;
            const cap = (c.parameters.c as number) || 1e-5;
            const period = 0.693 * (r1 + 2 * r2) * cap;
            const f = 1 / period;
            if (f > 0 && f < minFreq) minFreq = f;
          }
        }
      }

      if (minFreq !== Infinity && minFreq > 0) {
        const currentTime = result.sim.time;
        const phase = (currentTime * minFreq) % 1;
        const timeToRisingEdge = (1.0 - phase) / minFreq;
        const advance = Math.min(0.016, timeToRisingEdge + 0.001);
        if (advance > dt) {
          const newTime = currentTime + advance;
          prev.time = newTime;
          result.sim.time = newTime;
        }
      }
    }
    if (!result) {
      // Solver failed — likely singular matrix (no ground, or conflicting voltage sources)
      const hasGround = simComponents.some(c => c.type === 'ground');
      const errorMsg = !hasGround
        ? 'Simulation failed: No ground reference found. Add a Ground component to your circuit.'
        : 'Simulation failed: Singular matrix. Check for conflicting voltage sources or short circuits.';
      set({ running: false, paused: true, simError: errorMsg });
      return;
    }
    // update traces for oscilloscope components — when using hierarchy, the
    // active sheet's oscilloscope IDs match the flattened IDs (no prefix when
    // on root). When inside a sub-sheet, oscilloscope IDs need prefix lookup.
    const traces = [...s.traces];
    for (const comp of simComponents) {
      if (comp.type !== 'oscilloscope') continue;
      const plugin = plugins.get('oscilloscope');
      if (!plugin) continue;
      const terminals = getTerminalsForComponent(comp, plugin, result.nodeMap);
      const measurements = plugin.measure(comp.parameters, terminals, result.sim);
      const v = parseFloat(measurements[0]?.value ?? '0');
      // .PRINT directive: if printNodes is set, log matching node voltages to console
      if (s.simOptions.printNodes && s.simOptions.printNodes.length > 0) {
        for (const termKey of s.simOptions.printNodes) {
          const nodeId = result.nodeMap.terminalNode.get(termKey);
          if (nodeId != null && nodeId > 0) {
            const nodeV = result.sim.nodeVoltage[nodeId - 1] ?? 0;
            // eslint-disable-next-line no-console
            console.log(`[.PRINT t=${result.sim.time.toFixed(6)}] V(${termKey}) = ${nodeV.toFixed(6)} V`);
          }
        }
      }
      // When using hierarchy, the trace's componentId is the active sheet's local ID
      // (without prefix). Map back: if comp.id contains a '.', strip the prefix.
      const traceKey = usingHierarchy && comp.id.includes('.') ? comp.id.split('.').slice(1).join('.') : comp.id;
      let traceIdx = traces.findIndex((t) => t.componentId === traceKey);
      if (traceIdx < 0) {
        traces.push({
          componentId: traceKey,
          color: (comp.parameters.color as string) || '#22d3ee',
          label: (comp.parameters.label as string) || 'CH',
          samples: [],
        });
        traceIdx = traces.length - 1;
      }
      const trace = traces[traceIdx];
      trace.samples.push({ time: result.sim.time, voltage: v });
      if (trace.samples.length > s.maxTraceSamples) {
        trace.samples = trace.samples.slice(-s.maxTraceSamples);
      }
      traces[traceIdx] = { ...trace };
    }
    // Run physics validation (debug — catches simulation bugs).
    // Only runs when a special debug flag is set to avoid perf overhead in production.
    let physicsViolations: PhysicsViolation[] = s.physicsViolations;
    if (typeof window !== 'undefined' && (window as any).__PHYSICS_DEBUG__) {
      try {
        const validation = validatePhysics(simComponents, simWires, plugins, result.sim);
        physicsViolations = validation.violations;
        if (!validation.passed) {
          // eslint-disable-next-line no-console
          console.warn('[Physics] Violations detected:', validation.violations.length);
        }
      } catch (e) {
        // validation errors should never break the simulation
      }
    }
    set({ simContext: result.sim, traces, physicsViolations });
    } catch (err) {
      // Catch any unexpected errors from the simulation engine, plugins, or
      // hierarchy flattening. Prevents a single throwing plugin from killing
      // the RAF loop silently.
      const errorMsg = `Simulation error: ${(err as Error).message || 'Unknown error'}`;
      set({ running: false, paused: true, simError: errorMsg });
    }
  },

  reset: () => {
    set((s) => ({
      running: false,
      paused: true,
      components: s.components.map((c) => ({ ...c, simState: undefined })),
      simContext: null,
      simError: null,
      physicsViolations: [],
      traces: [],
      wireDraft: null,
    }));
  },

  setShowGrid: (showGrid) => set({ showGrid }),
  setSnapToGrid: (snapToGrid) => set({ snapToGrid }),

  // ── Advanced analysis ──────────────────────────────────────────────────────
  lastAnalysisResult: null,
  simOptions: { ...DEFAULT_OPTIONS },

  runAnalysis: (config) => {
    const s = get();
    const plugins = new Map<string, any>();
    for (const c of s.components) {
      const p = getPlugin(c.type);
      if (p) plugins.set(c.type, p);
    }
    const result = runAnalysisEngine(s.components, s.wires, plugins, config, s.simOptions);
    set({ lastAnalysisResult: result });
    return result;
  },

  runBatch: (config) => {
    const s = get();
    const plugins = new Map<string, any>();
    for (const c of s.components) {
      const p = getPlugin(c.type);
      if (p) plugins.set(c.type, p);
    }
    return runBatchEngine(s.components, s.wires, plugins, config, s.simOptions);
  },

  runMeasurement: (cmd, trace) => {
    return execMeas(cmd, trace);
  },

  setSimOptions: (patch) => {
    set((s) => ({ simOptions: { ...s.simOptions, ...patch } }));
  },

  solveDCRobust: () => {
    const s = get();
    const plugins = new Map<string, any>();
    for (const c of s.components) {
      const p = getPlugin(c.type);
      if (p) plugins.set(c.type, p);
    }
    return solveDCRobustEngine(s.components, s.wires, plugins, s.simOptions);
  },
}));
